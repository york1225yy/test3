// SPDX-License-Identifier: BSD-2-Clause
/*
 * Copyright 2020-2021 NXP
 */
#include <caam_hal_cfg.h>

void caam_hal_cfg_setup_nsjobring(struct caam_jrcfg *jrcfg __unused)
{
}
