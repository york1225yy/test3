// SPDX-License-Identifier: BSD-2-Clause
/*
 * Copyright (c) 2022, Linaro Limited
 */
#include <compiler.h>
#include <drivers/clk.h>
#include <stm32_util.h>

const struct clk_ops stm32mp1_clk_ops __rodata_dummy;
