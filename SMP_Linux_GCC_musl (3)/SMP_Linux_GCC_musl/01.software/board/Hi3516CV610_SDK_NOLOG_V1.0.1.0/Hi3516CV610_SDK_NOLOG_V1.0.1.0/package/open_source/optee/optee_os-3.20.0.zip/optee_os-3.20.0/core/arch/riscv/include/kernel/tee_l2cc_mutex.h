/* SPDX-License-Identifier: BSD-2-Clause */
/*
 * Copyright 2022 NXP
 */
#ifndef TEE_L2CC_MUTEX_H
#define TEE_L2CC_MUTEX_H

#endif /* TEE_L2CC_MUTEX_H */
