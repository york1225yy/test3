/* SPDX-License-Identifier: BSD-2-Clause */
/*
 * Copyright 2022 NXP
 */

#ifndef __KERNEL_CACHE_HELPERS_ARCH_H
#define __KERNEL_CACHE_HELPERS_ARCH_H

#endif /*__KERNEL_CACHE_HELPERS_ARCH_H*/
